package com.example.management_hospital

data class Appointment(
    val patientName: String = "",
    val age: String = "",
    val mobileNumber: String = "",
    val gender: String = "",
    val date: String = "",
    val timeSlot: String = ""
)
